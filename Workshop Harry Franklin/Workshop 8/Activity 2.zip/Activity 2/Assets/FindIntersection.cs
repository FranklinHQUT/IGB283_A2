using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindIntersection : MonoBehaviour
{
    public GameObject plane;
    public GameObject line;
    public GameObject intersection;

    public Vector3[] planeCorners;
    public Material planeMaterial;

    private Mesh mesh;

    public Vector3[] lineEnds;
    public float lineWidth;

    private LineRenderer lr;

    void Start()
    {
        SetupPlane();
        SetupLine();
        FindIntersectionLocation();
    }

    void SetupPlane()
    {
        plane.AddComponent<MeshFilter>();
        plane.AddComponent<MeshRenderer>();

        mesh = plane.GetComponent<MeshFilter>().mesh;

        plane.GetComponent<MeshRenderer>().material = planeMaterial;

        mesh.Clear();

        mesh.vertices = new Vector3[]
        {
            planeCorners[0],
            planeCorners[1],
            planeCorners[2],
            planeCorners[3]
        };

        mesh.colors = new Color[]
        {
            new Color(0.8f, 0.8f, 0.8f, 1.0f),
            new Color(0.8f, 0.8f, 0.8f, 1.0f),
            new Color(0.8f, 0.8f, 0.8f, 1.0f),
            new Color(0.8f, 0.8f, 0.8f, 1.0f)
        };

        mesh.triangles = new int[] {0, 1, 2, 0, 2, 3};
    }

    void SetupLine()
    {
        lr = line.GetComponent<LineRenderer>();
        lr.widthMultiplier = lineWidth;
        lr.positionCount = 2;
        lr.SetPosition(0, lineEnds[0]);
        lr.SetPosition(1, lineEnds[1]);
    }

    void FindIntersectionLocation()
    {
        Vector3[] vertices = mesh.vertices;
        int[] triangles = mesh.triangles;

        Vector3 p0 = vertices[triangles[1]];
        Vector3 p1 = vertices[triangles[0]];
        Vector3 p2 = vertices[triangles[2]];

        Vector3 la = lineEnds[0];
        Vector3 lb = lineEnds[1];

        Matrix4x4 M = new Matrix4x4();
        M.SetRow(0, new Vector4(la.x - lb.x, p1.x - p0.x, p2.x - p0.x, 0.0f));
        M.SetRow(1, new Vector4(la.y - lb.y, p1.y - p0.y, p2.y - p0.y, 0.0f));
        M.SetRow(2, new Vector4(la.z - lb.z, p1.z - p0.z, p2.z - p0.z, 0.0f));
        M.SetRow(3, new Vector4(0.0f, 0.0f, 0.0f, 1.0f));
        M = M.inverse;

        Vector3 vector = new Vector3(la.x - p0.x, la.y - p0.y, la.z - p0.z);
        
        Vector3 tuv = M.MultiplyPoint(vector);
        float t = tuv.x;
        float u = tuv.y;
        float v = tuv.z;

        bool onLine = (t <= 1 && t >= 0);
        bool onPlane = (u <= 1 && u >= 0) && (v <= 1 && v >= 0);

        if (onLine && onPlane)
        {
            intersection.transform.position = la + (lb - la) * t;
        } else
        {
            Debug.Log("The line and plane do not intersect");
        }
    }
}
