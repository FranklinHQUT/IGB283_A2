using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotateAroundSun : MonoBehaviour
{
    public float rotationSpeed = 10f;
    public float distFromSun;
    MeshFilter meshFilter;

    public float orbitSpeed;

    public Matrix3x3 parentTransform = null;

    void Start()
    {
        meshFilter = GetComponent<MeshFilter>(); 
        Matrix3x3 T = IGB283Transform.Translate(new Vector3(distFromSun, 0, 0));
        // combine the transformation matrices
        Matrix3x3 M = T;

        // apply the transformation to the vertices
        Mesh mesh = meshFilter.mesh;
        Vector3[] transformedVertices = new Vector3[mesh.vertices.Length];
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            transformedVertices[i] = M.MultiplyPoint(mesh.vertices[i]);
        }

        // update mesh vertices with the transformed vertices
        mesh.vertices = transformedVertices;
        mesh.RecalculateBounds();
    }

    void Update() 
    {
        Mesh mesh = meshFilter.mesh;

        // calc the transformation matrices
        Matrix3x3 T = IGB283Transform.Translate(mesh.bounds.center);
        Matrix3x3 R = IGB283Transform.Rotate(rotationSpeed * Time.deltaTime);
        Matrix3x3 T2 = IGB283Transform.Translate(-mesh.bounds.center);
        // combine the transformation matrices
        Matrix3x3 R2 = IGB283Transform.Rotate(orbitSpeed * Time.deltaTime);
        Matrix3x3 M = R2 * T * R * T2;

        if (transform.childCount > 0) // if has child, it's earth, child is the moon
        {
            transform.GetChild(0).GetComponent<rotateAroundSun>().parentTransform = M;
        }

        if (parentTransform != null)
        {
            M = parentTransform; // for moon, if has transform already, do it
        }

        // apply the transformation to the vertices
        Vector3[] transformedVertices = new Vector3[mesh.vertices.Length];
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            transformedVertices[i] = M.MultiplyPoint(mesh.vertices[i]);
        }

        // update mesh vertices with the transformed vertices
        mesh.vertices = transformedVertices;
        mesh.RecalculateBounds();

    }

}
