using UnityEngine;
using System.Collections;

public class Rectangle : MonoBehaviour 
{
    private Vector3 offset;

    public Material material;
    // Use this for initialization
    public float angle = 10f;
    Mesh mesh;

    void Start () 
    {
        // Add a MeshFilter and MeshRenderer to the Empty GameObject
        gameObject.AddComponent<MeshFilter>();
        gameObject.AddComponent<MeshRenderer>();
        // Get the Mesh from the MeshFilter
        mesh = GetComponent<MeshFilter>().mesh;
        // Set the material to the material we have selected
        GetComponent<MeshRenderer>().material = material;
        // Clear all vertex and index data from the mesh
        mesh.Clear();
        // Create a triangle with points at (0, 0, 0), (0, 1, 0) and (1, 1, 0)
        mesh.vertices = new Vector3[] 
        {
            new Vector3(0, 0, 1),
            new Vector3(0, 1, 1),
            new Vector3(1, 1, 1),
            new Vector3(1, 0, 1)
        };
        // Set the colour of the triangle
        mesh.colors = new Color[] 
        {
            new Color(0.8f, 0.3f, 0.3f, 1.0f),
            new Color(0.8f, 0.3f, 0.3f, 1.0f),
            new Color(0.8f, 0.3f, 0.3f, 1.0f),
            new Color(0.8f, 0.3f, 0.3f, 1.0f)
        };
        // Set vertex indicies
        mesh.triangles = new int[]{0, 1, 2, 0, 2, 3};

        // calc rectangle bounds
        offset.x = mesh.bounds.size.x / 2;
        offset.y = mesh.bounds.size.y / 2;
    }

    Matrix3x3 Translate(Vector3 offset)
    {
        Matrix3x3 matrix = new Matrix3x3();

        matrix.SetRow(0, new Vector3(1.0f, 0.0f, offset.x));
        matrix.SetRow(1, new Vector3(0.0f, 1.0f, offset.y));
        matrix.SetRow(2, new Vector3(0.0f, 0.0f, 1.0f));

        return matrix;
    }

    void Update()
    {
        // calc the transformation matrices
        Matrix3x3 T = Translate(offset);
        Matrix3x3 R = IGB283Transform.Rotate(angle * Time.deltaTime);
        Matrix3x3 T2 = Translate(-offset);

        // combine the transformation matrices
        Matrix3x3 M = T * R * T2;

        // apply the transformation to the vertices
        Vector3[] transformedVertices = new Vector3[mesh.vertices.Length];
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            transformedVertices[i] = M.MultiplyPoint(mesh.vertices[i]);
        }

        // update mesh vertices with the transformed vertices
        mesh.vertices = transformedVertices;
        mesh.RecalculateBounds();
    }
}