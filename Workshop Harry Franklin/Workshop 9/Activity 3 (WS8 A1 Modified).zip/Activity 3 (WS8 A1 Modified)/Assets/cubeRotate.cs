using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cubeRotate : MonoBehaviour
{
    Mesh mesh; // mesh data

    public Vector3 angle = new Vector3(0.0f, 10.0f, 0.0f); // rotation per frame

    void Start()
    {
        mesh = GetComponent<MeshFilter>().mesh;
    }

    void Update()
    {
        Vector3[] vertices = mesh.vertices; // get vertices from mesh
        Matrix4x4 R = Rotate(angle * Time.deltaTime);
        Matrix4x4 M = R;

        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] = M.MultiplyPoint(vertices[i]);
        }

        mesh.vertices = vertices;
        mesh.RecalculateBounds();
    }

    Matrix4x4 Rotate(Vector3 rotationAroundAllAxes)
    {
        float thetaX = rotationAroundAllAxes[0];
        float thetaY = rotationAroundAllAxes[1];
        float thetaZ = rotationAroundAllAxes[2];

        Matrix4x4 matX = new Matrix4x4();
        Matrix4x4 matY = new Matrix4x4();
        Matrix4x4 matZ = new Matrix4x4();

        matX.SetRow(0, new Vector4(1, 0, 0, 0));
        matX.SetRow(1, new Vector4(0, (float)Mathf.Cos(thetaX), -(float)Mathf.Sin(thetaX), 0));
        matX.SetRow(2, new Vector4((float)Mathf.Sin(thetaX), (float)Mathf.Cos(thetaX), 0));
        matX.SetRow(3, new Vector4(0, 0, 0, 1));

        matY.SetRow(0, new Vector4((float)Mathf.Cos(thetaY), 0, (float)Mathf.Sin(thetaY), 0));
        matY.SetRow(1, new Vector4(0, 1, 0, 0));
        matY.SetRow(2, new Vector4(-(float)Mathf.Sin(thetaY), 0, (float)Mathf.Cos(thetaY), 0));
        matY.SetRow(3, new Vector4(0, 0, 0, 1));

        matZ.SetRow(0, new Vector4((float)Mathf.Cos(thetaZ), -(float)Mathf.Sin(thetaZ), 0, 0));
        matZ.SetRow(1, new Vector4((float)Mathf.Sin(thetaZ), (float)Mathf.Cos(thetaZ), 0, 0));
        matZ.SetRow(2, new Vector4(0, 0, 1, 0));
        matZ.SetRow(3, new Vector4(0, 0, 0, 1));

        Matrix4x4 rotatedMatrix = matX * matY * matZ;
        return rotatedMatrix;
    }
}
