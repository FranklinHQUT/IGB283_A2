using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FindIntersection : MonoBehaviour
{
    public GameObject cube;
    public GameObject line;
    public GameObject intersection;

    public Vector3[] cubeCorners;
    public Material cubeMaterial;

    private Mesh mesh;

    public Vector3[] lineEnds;
    public float lineWidth;

    private LineRenderer lr;

    void Start()
    {
        SetupCube();
        SetupLine();
        FindIntersectionFaces();
    }

    void SetupCube()
    {
        mesh = cube.GetComponent<MeshFilter>().mesh;
        cube.GetComponent<MeshRenderer>().material = cubeMaterial;
    }

    void SetupLine()
    {
        lr = line.GetComponent<LineRenderer>();
        lr.widthMultiplier = lineWidth;
        lr.positionCount = 2;
        lr.SetPosition(0, lineEnds[0]);
        lr.SetPosition(1, lineEnds[1]);
    }

    bool FindIntersectionLocation (Vector3 p0, Vector3 p1, Vector3 p2, Vector3 la, Vector3 lb) 
    {
        Vector3[] vertices = mesh.vertices;
        int[] triangles = mesh.triangles;

        Matrix4x4 M = new Matrix4x4();
        M.SetRow(0, new Vector4(la.x - lb.x, p1.x - p0.x, p2.x - p0.x, 0.0f));
        M.SetRow(1, new Vector4(la.y - lb.y, p1.y - p0.y, p2.y - p0.y, 0.0f));
        M.SetRow(2, new Vector4(la.z - lb.z, p1.z - p0.z, p2.z - p0.z, 0.0f));
        M.SetRow(3, new Vector4(0.0f, 0.0f, 0.0f, 1.0f));
        M = M.inverse;

        Vector3 vector = new Vector3(la.x - p0.x, la.y - p0.y, la.z - p0.z);
        
        Vector3 tuv = M.MultiplyPoint(vector);
        float t = tuv.x;
        float u = tuv.y;
        float v = tuv.z;

        bool onLine = (t <= 1 && t >= 0);
        bool onCube = (u <= 1 && u >= 0) && (v <= 1 && v >= 0);

        // Set location if on line and plane
        if (onLine && onCube) 
        {
            // Spawn a new intersection point
            // Return True
            GameObject intersectionInstance = Instantiate(intersection);
            intersectionInstance.transform.position = la + (lb - la) * t;
            return true;
        }
        return false;
    }

    void FindIntersectionFaces()
    {
        int intersectionCount = 0;

        // Test intersection with every triangle of the mesh
        for (int i = 0; i < mesh.triangles.Length; i += 3) 
        {
            // Find the important points (As we are using the default cube we need to perform some transformations)
            Vector3 p0 = (mesh.vertices[mesh.triangles[i + 1]] * cube.transform.localScale.x) + cube.transform.position;
            Vector3 p1 = (mesh.vertices[mesh.triangles[i + 0]] * cube.transform.localScale.x) + cube.transform.position;
            Vector3 p2 = (mesh.vertices[mesh.triangles[i + 2]] * cube.transform.localScale.x) + cube.transform.position;
            Vector3 la = lineEnds[0];
            Vector3 lb = lineEnds[1];
            
            // Find all the intersections
            if (FindIntersectionLocation(p0, p1, p2, la, lb)) { intersectionCount++; }
        }

        Debug.Log("There have been " + intersectionCount.ToString() + " intersections.");
    }
}
